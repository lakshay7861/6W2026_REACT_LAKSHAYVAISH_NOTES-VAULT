import { createUserWithEmailAndPassword } from "firebase/auth"
import UserModel from "../Models/UserModel"
import { doc, setDoc } from "firebase/firestore"
import { db } from "../Firebase/FirebaseConfig"
class UserService {
    async register(payload) {
        const UserRegister = await createUserWithEmailAndPassword(auth, payload.email, payload.password)


        let newUser = new UserModel()

        newUser.name = payload.name;
        newUser.email = payload.email;
        newUser.phone = payload.phone;
        newUser.userType = 3;
        newUser.id = UserRegister.user.uid


await setDoc(doc(db, "users", userRegister.user.uid), {...newUser})
console.log("Users register data:",userRegister.user)

    }
}
export default new UserService