class UserService {
    name = ""
    email = ""
    phone = ""
    address = ""
    profileImage = ""
    userType =  3 //" admin/alumni/student" 1-admin  2-alumni 3-student
    isVerified = false
    status = "active"
    createdAt = ""
    updatedAt = ""
}
export default new UserService();