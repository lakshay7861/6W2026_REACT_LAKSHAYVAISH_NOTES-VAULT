import { useState } from "react"
import "./Header.css"

const courses = [
  { key: "btech", name: "B-Tech" },
  { key: "bsc", name: "B-Sc" },
  { key: "bcom", name: "B-Com" },
  { key: "mtech", name: "M-Tech" },
  { key: "msc", name: "M-Sc" },
]

function Header() {
  const [navOpen, setNavOpen] = useState(false)
  const [openMenus, setOpenMenus] = useState({})

  const closeNav = () => {
    setNavOpen(false)
    setOpenMenus({})
  }

  const toggleSub = (e, key) => {
    e.preventDefault()
    setOpenMenus((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <>
      <header id="header" className="header d-flex align-items-center sticky-top">
        <div className="container-fluid container-xl position-relative d-flex align-items-center">
          <a href="/" className="logo d-flex align-items-center me-auto text-decoration-none" onClick={closeNav}>
            {/* Uncomment the line below if you also wish to use an image logo */}
            {/* <img src="assets/img/logo.webp" alt=""> */}
            <h1 className="sitename">Notes Vault</h1>
          </a>

          <nav id="navmenu" className={`navmenu ${navOpen ? "open" : ""}`}>
            <ul>
              <li>
                <a href="/" className="text-decoration-none" onClick={closeNav}>
                  Home
                </a>
              </li>
              <li>
                <a href="/about" className="text-decoration-none" onClick={closeNav}>About</a>
              </li>
              <li>
                <a href="/course" className="text-decoration-none" onClick={closeNav}>Course</a>
              </li>

              <li className={`dropdown ${openMenus.paper ? "open-sub" : ""}`}>
                <a href="#" className="text-decoration-none" onClick={(e) => toggleSub(e, "paper")}>
                  <span className="text-decoration-none">Question Paper</span>{" "}
                  <i className="bi bi-chevron-right toggle-dropdown text-decoration-none" />
                </a>

                <ul>
                  {courses.map((course) => (
                    <li
                      key={course.key}
                      className={`dropdown ${openMenus[course.key] ? "open-sub" : ""}`}
                    >
                      <a href="#" onClick={(e) => toggleSub(e, course.key)}>
                        <span>{course.name}</span>{" "}
                        <i className="bi bi-chevron-down toggle-dropdown" />
                      </a>

                      <ul>
                        {[1, 2, 3, 4, 5].map((n) => (
                          <li key={n}>
                            <a href="#" onClick={closeNav}>Deep Dropdown {n}</a>
                          </li>
                        ))}
                      </ul>
                    </li>
                  ))}
                </ul>
              </li>

              <li>
                <a href="/login" className="text-decoration-none" onClick={closeNav}>Login</a>
              </li>
              <li>
                <a href="/register" className="text-decoration-none" onClick={closeNav}>Register</a>
              </li>
            </ul>
          </nav>

          <button
            className="mobile-nav-toggle"
            aria-label="Menu kholo ya band karo"
            aria-expanded={navOpen}
            onClick={() => setNavOpen(!navOpen)}
          >
            {navOpen ? "✕" : "☰"}
          </button>

                  
        </div>
      </header>
    </>
  )
}

export default Header